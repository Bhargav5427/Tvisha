---
name: Heritage Digital
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#3e4948'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#6e7979'
  outline-variant: '#bec9c8'
  surface-tint: '#006a69'
  primary: '#006766'
  on-primary: '#ffffff'
  primary-container: '#268180'
  on-primary-container: '#f3fffe'
  inverse-primary: '#81d4d3'
  secondary: '#934a32'
  on-secondary: '#ffffff'
  secondary-container: '#ffa183'
  on-secondary-container: '#78351f'
  tertiary: '#755715'
  on-tertiary: '#ffffff'
  tertiary-container: '#906f2c'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9ef1ef'
  primary-fixed-dim: '#81d4d3'
  on-primary-fixed: '#002020'
  on-primary-fixed-variant: '#00504f'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59e'
  on-secondary-fixed: '#3a0b00'
  on-secondary-fixed-variant: '#75331d'
  tertiary-fixed: '#ffdea5'
  tertiary-fixed-dim: '#e9c175'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5d4200'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1440px
  gutter: 24px
---

## Brand & Style

The design system is a sophisticated synthesis of high-density SaaS utility and editorial luxury. It targets a discerning audience looking for premium ethnic wear through a platform that feels as reliable as a professional tool and as inspiring as a fashion magazine. 

The aesthetic is **Minimalist-Luxe**. It leverages heavy whitespace, precision-aligned grids, and a "workspace" density to handle complex product attributes (fabric, embroidery type, sizing) without clutter. The emotional response should be one of "effortless elegance"—the UI recedes to let the intricate textures of the Chaniya Cholis take center stage, while subtle gold accents and smooth transitions signal a premium, high-touch service.

## Colors

The palette is rooted in a "Modern Heritage" theme. 
- **Primary (Teal):** Used for primary actions and brand presence. It offers a professional, calming contrast to the often vibrant colors of the garments.
- **Secondary (Terracotta):** Reserved for seasonal highlights, earthy accents, and soft alerts.
- **Accent (Gold):** Used sparingly for "premium" signifiers, such as membership badges, price highlights, or subtle hover states.
- **Surface:** The background utilizes a subtle gold-tinted gradient to prevent the UI from feeling "cold" or clinical, maintaining a warm, hospitable atmosphere.

## Typography

This design system uses a high-contrast typographic pairing to balance tradition and modernity. 

**Playfair Display** provides an authoritative, editorial voice for headings and product titles. It should be used with tighter tracking in larger sizes to emphasize its elegant serifs. 

**Plus Jakarta Sans** is the workhorse for all functional UI elements. Its slightly wider apertures and modern geometric construction ensure high legibility in dense data views (like inventory tables) and mobile product descriptions. Use `label-md` for metadata and category tags to maintain a structured, organized feel.

## Layout & Spacing

The system employs a **Fixed Grid** layout for desktop (12 columns) to maintain a curated, boutique feel. 

- **Desktop (1440px+):** 12 columns, 24px gutters, 80px side margins. 
- **Tablet (768px - 1439px):** 8 columns, 20px gutters, 40px side margins.
- **Mobile (<768px):** 4 columns, 16px gutters, 16px side margins.

A strict 8px spacing power-of-two scale ensures consistency. In "SaaS-style" admin views, the density should increase by utilizing the `sm` (12px) and `xs` (4px) units for padding within tables and forms. Consumer-facing pages should lean on `lg` (48px) and `xl` (80px) vertical spacing to create a luxurious sense of "breathing room."

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Soft Ambient Shadows**. 

1.  **Level 0 (Base):** The linear-gradient background.
2.  **Level 1 (Cards/Surface):** White surfaces with a 1px border in a very light gold (#F3E5AB) and no shadow.
3.  **Level 2 (Hover/Floating):** When a user interacts with a product card, it lifts using a highly diffused shadow: `0 12px 24px -8px rgba(61, 147, 146, 0.12)`. Note the subtle primary color (Teal) tint in the shadow to keep it harmonious with the brand.
4.  **Level 3 (Modals):** Centered overlays with a heavy backdrop blur (12px) to maintain the focus on the luxurious content.

Avoid heavy blacks or harsh dropshadows. The goal is to simulate soft, natural light hitting premium fabric.

## Shapes

The design system uses a **Rounded** (Level 2) shape language. 

- **Components (Buttons, Inputs):** 0.5rem (8px) corner radius. This provides a modern, friendly touch that softens the "technical" SaaS layout.
- **Containers (Cards, Modals):** 1rem (16px) corner radius to differentiate larger structural blocks from smaller interactive elements.
- **Media (Images):** Product photography should always use the same 1rem radius to maintain the soft-luxe aesthetic.

## Components

### Buttons
- **Primary:** Solid Teal (#3D9392) with white text. High-contrast, no gradient.
- **Secondary:** Ghost style with a Teal border and subtle gold-tinted hover fill.
- **CTA:** For "Buy Now" or "Limited Edition," use the Terracotta (#D17B60) color to draw immediate attention.

### Product Cards (Customer-Facing)
Cards must be clean with "Image-First" priority. Use a soft fade-in transition (300ms) for secondary images on hover. Text (Title/Price) should be center-aligned in Playfair Display.

### Admin Tables (SaaS-Density)
Tables use a collapsed border model with a subtle 1px divider (#F0F0F0). Row height is compact (48px). Use Plus Jakarta Sans at 14px for maximum data density. Status badges (In Stock, Shipped) use low-saturation background fills with high-saturation text.

### Inputs & Selects
Minimalist "Outlined" style. On focus, the border transitions from light grey to Teal (#3D9392) with a 2px outer glow in Gold (#CBA55C) at 20% opacity.

### Navigation
A sticky top-bar with a backdrop-blur effect. Links use `label-md` styling with a 2px underline transition on hover that expands from the center.